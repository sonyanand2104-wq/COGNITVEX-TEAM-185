import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import time
from streamlit.components.v1 import html
import random
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM

# --- Page Configuration ---
st.set_page_config(
    page_title="Financial Chat Bot",
    layout="wide",
    initial_sidebar_state="collapsed",
    page_icon="💰"
)

# --- Model and Tokenizer Loading (Cached for efficiency) ---
@st.cache_resource
def load_model():
    """Loads the pre-trained causal language model."""
    model = AutoModelForCausalLM.from_pretrained("ibm-granite/granite-3.3-2b-instruct")
    return model

@st.cache_resource
def load_tokenizer():
    """Loads the tokenizer for the model."""
    tokenizer = AutoTokenizer.from_pretrained("ibm-granite/granite-3.3-2b-instruct")
    return tokenizer

# Load the model and tokenizer
model = load_model()
tokenizer = load_tokenizer()


# --- CSS Styling for Animations and Professional Look ---
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;600;700&display=swap');
            
* {
    font-family: 'Montserrat', sans-serif;
}

.main-header {
    font-size: 4rem;
    font-weight: 700;
    text-align: center;
    margin: 2rem 0;
    background: linear-gradient(90deg, #0077b6, #00b4d8, #0077b6);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    animation: shimmer 3s infinite linear;
    cursor: pointer;
    transition: all 0.5s ease;
}

.main-header:hover {
    transform: scale(1.05);
}

@keyframes shimmer {
    0% { background-position: -100% 0; }
    100% { background-position: 200% 0; }
}

.role-button {
    padding: 1rem 2rem;
    border-radius: 10px;
    border: none;
    font-size: 1.2rem;
    font-weight: 600;
    margin: 1rem;
    transition: all 0.3s ease;
    background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
    color: white;
    box-shadow: 0 4px 6px rgba(0,0,0,0.1);
}

.role-button:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.2);
}

.advisor-button {
    background: linear-gradient(135deg, #ff9a9e 0%, #fad0c4 100%);
    color: #333;
    font-weight: 700;
}

.chat-bubble {
    background-color: #f8f9fa;
    border-radius: 20px;
    padding: 1.5rem;
    margin: 1rem 0;
    box-shadow: 0 4px 6px rgba(0,0,0,0.05);
    border-left: 5px solid #0077b6;
}

.expense-form {
    background-color: #f8f9fa;
    padding: 2rem;
    border-radius: 15px;
    margin: 1rem 0;
}

.fade-in {
    animation: fadeIn 1s;
}

@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

.slide-in {
    animation: slideIn 0.5s forwards;
    transform: translateX(-100%);
}

@keyframes slideIn {
    to { transform: translateX(0); }
}

.student-bg {
    background: linear-gradient(rgba(255,255,255,0.9), rgba(255,255,255,0.9)), url('https://images.unsplash.com/photo-1523050854058-8df90110c9f1?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80');
    background-size: cover;
    padding: 20px;
    border-radius: 15px;
}

.gym-bg {
    background: linear-gradient(rgba(255,255,255,0.9), rgba(255,255,255,0.9)), url('https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80');
    background-size: cover;
    padding: 20px;
    border-radius: 15px;
}

.employee-bg {
    background: linear-gradient(rgba(255,255,255,0.9), rgba(255,255,255,0.9)), url('https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80');
    background-size: cover;
    padding: 20px;
    border-radius: 15px;
}

.sports-bg {
    background: linear-gradient(rgba(255,255,255,0.9), rgba(255,255,255,0.9)), url('https://images.unsplash.com/photo-1461896836934-ffe607ba8211?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80');
    background-size: cover;
    padding: 20px;
    border-radius: 15px;
}

.advisor-bg {
    background: linear-gradient(rgba(255,255,255,0.9), rgba(255,255,255,0.9)), url('https://images.unsplash.com/photo-1589156280159-27698a70f29e?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80');
    background-size: cover;
    padding: 20px;
    border-radius: 15px;
}
</style>
""", unsafe_allow_html=True)

# --- Initialize Session State ---
if 'page' not in st.session_state:
    st.session_state.page = 'home'
if 'user_role' not in st.session_state:
    st.session_state.user_role = None
if 'expenses' not in st.session_state:
    st.session_state.expenses = []
if 'salary_data' not in st.session_state:
    st.session_state.salary_data = {}
if 'chat_messages' not in st.session_state:
    st.session_state.chat_messages = []

# --- Home Page with Animated Title ---
def home_page():
    st.markdown('<h1 class="main-header" onclick="window.location.reload()">Financial Chat Bot</h1>', unsafe_allow_html=True)
    
    # Create animation effect using empty containers and time delays
    placeholder = st.empty()
    
    for i in range(3):
        with placeholder.container():
            st.markdown(f'<h2 style="text-align: center; opacity: {0.3 * (i+1)};">Your Personal Finance Assistant</h2>', unsafe_allow_html=True)
        time.sleep(0.5)
    
    st.markdown("""
    <div style='text-align: center; margin-bottom: 3rem;'>
        <p style='font-size: 1.2rem;'>Select your profile to get personalized financial advice</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Role selection buttons
    col1, col2 = st.columns(2)
    with col1:
        if st.button('👨‍🎓 Student', key='student_btn', use_container_width=True):
            st.session_state.user_role = 'Student'
            st.session_state.page = 'dashboard'
            st.rerun()
            
        if st.button('💪 Body Building', key='bodybuilding_btn', use_container_width=True):
            st.session_state.user_role = 'Body Building'
            st.session_state.page = 'dashboard'
            st.rerun()
            
    with col2:
        if st.button('👨‍💼 Employee', key='employee_btn', use_container_width=True):
            st.session_state.user_role = 'Employee'
            st.session_state.page = 'dashboard'
            st.rerun()
            
        if st.button('⚽ Sports Person', key='sports_btn', use_container_width=True):
            st.session_state.user_role = 'Sports Person'
            st.session_state.page = 'dashboard'
            st.rerun()
    
    st.markdown("---")
    
    # Finance Advisor Button
    if st.button('🧠 Finance Advisor Chat', key='advisor_btn', use_container_width=True, type='primary'):
        st.session_state.user_role = 'Advisor'
        st.session_state.page = 'advisor'
        st.rerun()

# --- Student Dashboard ---
def student_dashboard():
    st.markdown(f"<h2 style='text-align: center;'>🎓 {st.session_state.user_role} Dashboard</h2>", unsafe_allow_html=True)
    
    tab1, tab2, tab3 = st.tabs(["💰 Expense Tracker", "💡 Money Saving Tips", "📈 Financial Health"])
    
    with tab1:
        st.markdown('<div class="student-bg">', unsafe_allow_html=True)
        st.subheader("Track Your Expenses")
        
        col1, col2 = st.columns([1, 2])
        
        with col1:
            with st.form("expense_form", clear_on_submit=True):
                category = st.selectbox("Category", ["Books", "Stationary", "Tuition", "Hostel", "Food", "Transport", "Entertainment", "Other"])
                amount = st.number_input("Amount ($)", min_value=0.0, step=1.0)
                note = st.text_input("Note (optional)")
                submitted = st.form_submit_button("Add Expense")
                
                if submitted:
                    st.session_state.expenses.append({
                        "Category": category,
                        "Amount": amount,
                        "Note": note,
                        "Date": pd.Timestamp.now().strftime("%Y-%m-%d")
                    })
                    st.success("Expense added successfully!")
        
        with col2:
            if st.session_state.expenses:
                df = pd.DataFrame(st.session_state.expenses)
                
                # Display expenses table
                st.dataframe(df, use_container_width=True, hide_index=True)
                
                # Calculate and display total
                total = df["Amount"].sum()
                st.metric("Total Expenses", f"${total:.2f}")
                
                # Create pie chart
                fig, ax = plt.subplots()
                pie_data = df.groupby("Category").sum(numeric_only=True).reset_index()
                ax.pie(pie_data["Amount"], labels=pie_data["Category"], autopct="%1.1f%%", startangle=90)
                ax.axis("equal")
                st.pyplot(fig)
                
                # Budget warning
                if total > 200:
                    st.warning("⚠ You're spending more than $200 this month. Consider reviewing your budget!")
            else:
                st.info("No expenses recorded yet. Start adding your expenses above.")
        st.markdown('</div>', unsafe_allow_html=True)
    
    with tab2:
        st.markdown('<div class="student-bg">', unsafe_allow_html=True)
        st.subheader("Money Saving Tips for Students")
        
        tips = [
            "Use student discounts whenever possible - many stores, software companies, and services offer them",
            "Cook meals at home instead of eating out - it's healthier and cheaper",
            "Share subscriptions with roommates (Netflix, Spotify, etc.)",
            "Buy used textbooks or rent them instead of purchasing new",
            "Use public transportation or bike instead of owning a car",
            "Take advantage of free campus events for entertainment",
            "Use budgeting apps to track your spending habits",
            "Consider part-time work or freelance opportunities to supplement your income",
            "Limit eating out and coffee shop visits - these small expenses add up quickly"
        ]
        
        for i, tip in enumerate(tips):
            st.markdown(f"""
            <div class="chat-bubble fade-in">
                <h4>💡 Tip #{i+1}:</h4>
                <p>{tip}</p>
            </div>
            """, unsafe_allow_html=True)
        st.markdown('</div>', unsafe_allow_html=True)
    
    with tab3:
        st.markdown('<div class="student-bg">', unsafe_allow_html=True)
        st.subheader("Your Financial Health")
        
        if st.session_state.expenses:
            df = pd.DataFrame(st.session_state.expenses)
            spending_by_category = df.groupby("Category").sum(numeric_only=True).reset_index()
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.metric("Total Monthly Spending", f"${df['Amount'].sum():.2f}")
                st.metric("Average Daily Spending", f"${df['Amount'].sum()/30:.2f}")
            
            with col2:
                # Find category with highest spending
                max_category = spending_by_category.loc[spending_by_category['Amount'].idxmax()]
                st.metric("Highest Spending Category", f"{max_category['Category']} (${max_category['Amount']:.2f})")
                
                # Calculate potential savings
                potential_savings = df['Amount'].sum() * 0.15
                st.metric("Potential Monthly Savings", f"${potential_savings:.2f}")
            
            # Display progress bars for each category
            st.subheader("Spending Breakdown")
            for _, row in spending_by_category.iterrows():
                percentage = (row['Amount'] / df['Amount'].sum()) * 100
                st.markdown(f"""
                <div style="margin: 10px 0;">
                    <div style="display: flex; justify-content: space-between;">
                        <span>{row['Category']}</span>
                        <span>${row['Amount']:.2f} ({percentage:.1f}%)</span>
                    </div>
                    <div style="background: #e0e0e0; border-radius: 5px; height: 10px;">
                        <div style="background: linear-gradient(90deg, #0077b6, #00b4d8); width: {percentage}%; height: 10px; border-radius: 5px;"></div>
                    </div>
                </div>
                """, unsafe_allow_html=True)
            
            # Expense reduction plan
            st.subheader("Expense Reduction Plan")
            
            if max_category['Category'] == "Food" and max_category['Amount'] > 100:
                st.info("🍽 Your food expenses are high. Consider meal prepping and limiting eating out to save money.")
            elif max_category['Category'] == "Entertainment" and max_category['Amount'] > 50:
                st.info("🎬 Your entertainment expenses are high. Look for free campus events and student discounts.")
            elif max_category['Category'] == "Transport" and max_category['Amount'] > 60:
                st.info("🚌 Consider using public transportation or carpooling to reduce transport costs.")
            elif max_category['Category'] == "Books" and max_category['Amount'] > 80:
                st.info("📚 Look for used books, digital versions, or library rentals to save on textbook costs.")
            
            # Create a bar chart for better visualization
            fig, ax = plt.subplots(figsize=(10, 6))
            ax.bar(spending_by_category['Category'], spending_by_category['Amount'])
            ax.set_title('Expenses by Category')
            ax.set_ylabel('Amount ($)')
            plt.xticks(rotation=45)
            st.pyplot(fig)
        else:
            st.info("Add some expenses to see your financial health analysis")
        st.markdown('</div>', unsafe_allow_html=True)

# --- Employee Dashboard ---
def employee_dashboard():
    st.markdown(f"<h2 style='text-align: center;'>👨‍💼 {st.session_state.user_role} Dashboard</h2>", unsafe_allow_html=True)
    
    tab1, tab2, tab3 = st.tabs(["💰 Income & Expenses", "🏦 Savings Plan", "📈 Investment Advice"])
    
    with tab1:
        st.markdown('<div class="employee-bg">', unsafe_allow_html=True)
        st.subheader("Income and Expense Management")
        
        col1, col2 = st.columns(2)
        
        with col1:
            with st.form("salary_form"):
                st.subheader("Enter Your Income Details")
                salary = st.number_input("Monthly Salary ($)", min_value=0, step=100)
                additional_income = st.number_input("Additional Monthly Income ($)", min_value=0, step=100)
                tax_rate = st.slider("Estimated Tax Rate (%)", 0, 50, 25)
                
                submitted_income = st.form_submit_button("Save Income Details")
                
                if submitted_income:
                    st.session_state.salary_data = {
                        "salary": salary,
                        "additional_income": additional_income,
                        "tax_rate": tax_rate
                    }
                    st.success("Income details saved!")
        
        with col2:
            st.subheader("Monthly Expenses")
            
            if st.session_state.salary_data:
                net_income = (st.session_state.salary_data["salary"] + 
                              st.session_state.salary_data["additional_income"]) * \
                             (1 - st.session_state.salary_data["tax_rate"]/100)
                
                st.metric("Net Monthly Income", f"${net_income:,.2f}")
                
                # Expense categories
                expenses = {}
                col21, col22 = st.columns(2)
                
                with col21:
                    expenses["Housing"] = st.number_input("Housing ($)", min_value=0, value=1000, step=50)
                    expenses["Food"] = st.number_input("Food ($)", min_value=0, value=300, step=20)
                    expenses["Transport"] = st.number_input("Transport ($)", min_value=0, value=200, step=10)
                    expenses["Utilities"] = st.number_input("Utilities ($)", min_value=0, value=150, step=10)
                
                with col22:
                    expenses["Entertainment"] = st.number_input("Entertainment ($)", min_value=0, value=200, step=10)
                    expenses["Healthcare"] = st.number_input("Healthcare ($)", min_value=0, value=100, step=10)
                    expenses["Debt"] = st.number_input("Debt Payments ($)", min_value=0, value=200, step=10)
                    expenses["Other"] = st.number_input("Other Expenses ($)", min_value=0, value=100, step=10)
                
                total_expenses = sum(expenses.values())
                remaining_income = net_income - total_expenses
                
                st.metric("Total Expenses", f"${total_expenses:,.2f}")
                st.metric("Remaining Income", f"${remaining_income:,.2f}")
                
                if remaining_income < 0:
                    st.error("Your expenses exceed your income! Please adjust your budget.")
                elif remaining_income < net_income * 0.1:
                    st.warning("You have little leftover income. Consider reducing expenses.")
                else:
                    st.success("Your budget looks healthy!")
                    
                # Create expense breakdown chart
                expense_categories = list(expenses.keys())
                expense_values = list(expenses.values())
                
                fig, ax = plt.subplots()
                ax.pie(expense_values, labels=expense_categories, autopct='%1.1f%%', startangle=90)
                ax.axis('equal')
                ax.set_title('Monthly Expenses Breakdown')
                st.pyplot(fig)
        st.markdown('</div>', unsafe_allow_html=True)
    
    with tab2:
        st.markdown('<div class="employee-bg">', unsafe_allow_html=True)
        st.subheader("Personalized Savings Plan")
        
        if st.session_state.salary_data:
            net_income = (st.session_state.salary_data["salary"] + 
                          st.session_state.salary_data["additional_income"]) * \
                         (1 - st.session_state.salary_data["tax_rate"]/100)
            
            st.info("Based on your income, here's a recommended savings allocation:")
            
            # Savings recommendations
            emergency_fund = net_income * 0.2
            retirement = net_income * 0.15
            investments = net_income * 0.10
            personal_goals = net_income * 0.05
            
            st.markdown(f"""
            <div class="chat-bubble">
                <h4>💰 Emergency Fund: ${emergency_fund:,.2f}</h4>
                <p>For unexpected expenses (3-6 months of living expenses)</p>
            </div>
            """, unsafe_allow_html=True)
            
            st.markdown(f"""
            <div class="chat-bubble">
                <h4>🏦 Retirement: ${retirement:,.2f}</h4>
                <p>401(k), IRA, or other retirement accounts</p>
            </div>
            """, unsafe_allow_html=True)
            
            st.markdown(f"""
            <div class="chat-bubble">
                <h4>📈 Investments: ${investments:,.2f}</h4>
                <p>Stocks, bonds, or mutual funds for wealth building</p>
            </div>
            """, unsafe_allow_html=True)
            
            st.markdown(f"""
            <div class="chat-bubble">
                <h4>🎯 Personal Goals: ${personal_goals:,.2f}</h4>
                <p>Vacations, gadgets, or other personal objectives</p>
            </div>
            """, unsafe_allow_html=True)
            
            # Savings progress visualization
            savings_data = pd.DataFrame({
                'Category': ['Emergency Fund', 'Retirement', 'Investments', 'Personal Goals'],
                'Amount': [emergency_fund, retirement, investments, personal_goals]
            })
            
            fig, ax = plt.subplots()
            ax.pie(savings_data['Amount'], labels=savings_data['Category'], autopct='%1.1f%%', startangle=90)
            ax.axis('equal')
            ax.set_title('Recommended Savings Allocation')
            st.pyplot(fig)
            
            # Savings growth projection
            st.subheader("Savings Growth Projection")
            
            years = st.slider("Projection Period (Years)", 1, 30, 10)
            annual_return = st.slider("Expected Annual Return (%)", 1, 15, 7)
            
            # Calculate compound growth
            total_savings = emergency_fund + retirement + investments + personal_goals
            monthly_savings = total_savings
            future_value = total_savings
            yearly_values = [future_value]
            
            for year in range(1, years + 1):
                future_value = future_value * (1 + annual_return/100) + (monthly_savings * 12)
                yearly_values.append(future_value)
            
            # Display results
            st.metric(f"Projected Value after {years} years", f"${future_value:,.2f}")
            
            # Create growth chart
            fig, ax = plt.subplots()
            ax.plot(range(years + 1), yearly_values)
            ax.set_xlabel("Years")
            ax.set_ylabel("Portfolio Value ($)")
            ax.set_title("Savings Growth Projection")
            ax.grid(True)
            st.pyplot(fig)
        else:
            st.info("Please enter your income details in the Income & Expenses tab first")
        st.markdown('</div>', unsafe_allow_html=True)
    
    with tab3:
        st.markdown('<div class="employee-bg">', unsafe_allow_html=True)
        st.subheader("Investment Advice")
        
        st.markdown("""
        <div class="chat-bubble">
            <h4>📊 Diversify Your Portfolio</h4>
            <p>Consider spreading your investments across different asset classes to minimize risk.</p>
        </div>
        """, unsafe_allow_html=True)
        
        st.markdown("""
        <div class="chat-bubble">
            <h4>🏠 Real Estate Investment</h4>
            <p>Real estate can provide both rental income and property value appreciation over time.</p>
        </div>
        """, unsafe_allow_html=True)
        
        st.markdown("""
        <div class="chat-bubble">
            <h4>📱 Technology Stocks</h4>
            <p>The tech sector continues to show strong growth potential for long-term investors.</p>
        </div>
        """, unsafe_allow_html=True)
        
        # Interactive investment calculator
        st.subheader("Investment Growth Calculator")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            initial_investment = st.number_input("Initial Investment ($)", min_value=0, value=10000, step=1000)
        with col2:
            monthly_contribution = st.number_input("Monthly Contribution ($)", min_value=0, value=200, step=50)
        with col3:
            years = st.slider("Time Period (Years)", 1, 40, 10)
        
        annual_return = 7.0  # Average annual return percentage
        
        # Calculate compound growth
        future_value = initial_investment
        yearly_values = [future_value]
        
        for year in range(1, years + 1):
            future_value = future_value * (1 + annual_return/100) + (monthly_contribution * 12)
            yearly_values.append(future_value)
        
        # Display results
        st.metric("Projected Future Value", f"${future_value:,.2f}")
        
        # Create growth chart
        fig, ax = plt.subplots()
        ax.plot(range(years + 1), yearly_values)
        ax.set_xlabel("Years")
        ax.set_ylabel("Portfolio Value ($)")
        ax.set_title("Investment Growth Projection")
        ax.grid(True)
        st.pyplot(fig)
        
        # Risk assessment
        st.subheader("Risk Assessment")
        
        risk_tolerance = st.select_slider("Your Risk Tolerance", 
                                          options=["Very Conservative", "Conservative", "Moderate", "Aggressive", "Very Aggressive"])
        
        if risk_tolerance == "Very Conservative":
            st.info("Recommended: 70% Bonds, 20% Stocks, 10% Cash")
        elif risk_tolerance == "Conservative":
            st.info("Recommended: 50% Bonds, 40% Stocks, 10% Cash")
        elif risk_tolerance == "Moderate":
            st.info("Recommended: 40% Bonds, 50% Stocks, 10% Real Estate")
        elif risk_tolerance == "Aggressive":
            st.info("Recommended: 20% Bonds, 70% Stocks, 10% Alternative Investments")
        else:
            st.info("Recommended: 10% Bonds, 80% Stocks, 10% High-Risk Investments")
        st.markdown('</div>', unsafe_allow_html=True)

# --- Finance Advisor Chat (INTEGRATED WITH GRANITE LLM) ---
def advisor_chat():
    st.markdown(f"<h2 style='text-align: center;'>🧠 {st.session_state.user_role} Chat</h2>", unsafe_allow_html=True)
    st.markdown('<div class="advisor-bg">', unsafe_allow_html=True)

    # Add a system prompt to guide the AI if the chat is new
    if not st.session_state.chat_messages:
        st.session_state.chat_messages.append({
            "role": "system",
            "content": "You are a professional and friendly financial advisor. Provide clear, actionable, and concise advice on topics like budgeting, saving, investing, and debt management. Do not hallucinate or provide made-up information."
        })

    # Display chat messages from history
    for message in st.session_state.chat_messages:
        # Don't display the system message to the user
        if message["role"] != "system":
            with st.chat_message(message["role"]):
                st.markdown(message["content"])

    # Chat input
    if prompt := st.chat_input("Ask a financial question..."):
        # Add user message to chat history and display it
        st.session_state.chat_messages.append({"role": "user", "content": prompt})
        with st.chat_message("user"):
            st.markdown(prompt)

        # Generate AI response
        with st.chat_message("assistant"):
            message_placeholder = st.empty()
            message_placeholder.markdown("Thinking...▌")

            # Prepare messages for the model, excluding the system role for the tokenizer
            messages_for_model = [msg for msg in st.session_state.chat_messages if msg["role"] != "system"]

            # Use the tokenizer to create the input format
            inputs = tokenizer.apply_chat_template(
                messages_for_model,
                add_generation_prompt=True,
                tokenize=True,
                return_dict=True,
                return_tensors="pt",
            ).to(model.device)

            # Generate the output
            outputs = model.generate(**inputs, max_new_tokens=512, do_sample=True, temperature=0.7, top_p=0.95)
            
            # Decode only the newly generated tokens
            response = tokenizer.decode(outputs[0][inputs["input_ids"].shape[-1]:], skip_special_tokens=True)

            # Simulate stream of response for better UX
            full_response = ""
            for chunk in response.split():
                full_response += chunk + " "
                time.sleep(0.05)
                message_placeholder.markdown(full_response + "▌")
            
            message_placeholder.markdown(full_response)
        
        # Add the complete AI response to the chat history
        st.session_state.chat_messages.append({"role": "assistant", "content": full_response})

    st.markdown('</div>', unsafe_allow_html=True)

# --- Body Building Dashboard ---
def bodybuilding_dashboard():
    st.markdown(f"<h2 style='text-align: center;'>💪 {st.session_state.user_role} Dashboard</h2>", unsafe_allow_html=True)
    st.markdown('<div class="gym-bg">', unsafe_allow_html=True)
    
    st.info("Specialized financial planning for bodybuilders - balancing nutrition costs with fitness goals")
    
    tab1, tab2 = st.tabs(["💰 Budget Planner", "💪 Fitness Finance Tips"])
    
    with tab1:
        st.subheader("Nutrition Budget Planner")
        
        col1, col2 = st.columns(2)
        
        with col1:
            protein = st.number_input("Monthly Protein Supplement Cost ($)", min_value=0, value=100, step=10)
            vitamins = st.number_input("Monthly Vitamins/Supplements ($)", min_value=0, value=50, step=5)
            special_diet = st.number_input("Monthly Special Diet Food ($)", min_value=0, value=200, step=10)
            
        with col2:
            gym = st.number_input("Monthly Gym Membership ($)", min_value=0, value=50, step=5)
            training = st.number_input("Monthly Training Fees ($)", min_value=0, value=100, step=10)
            equipment = st.number_input("Monthly Equipment Costs ($)", min_value=0, value=50, step=5)
            
        total_fitness = protein + vitamins + special_diet + gym + training + equipment
        
        st.metric("Total Monthly Fitness Expenses", f"${total_fitness}")
        
        # Fitness expense analysis
        categories = ["Protein", "Vitamins", "Special Diet", "Gym", "Training", "Equipment"]
        values = [protein, vitamins, special_diet, gym, training, equipment]
        
        fig, ax = plt.subplots()
        ax.pie(values, labels=categories, autopct='%1.1f%%', startangle=90)
        ax.axis('equal')
        ax.set_title('Fitness Expenses Breakdown')
        st.pyplot(fig)
        
        if total_fitness > 300:
            st.warning("Consider looking for discounts on supplements or sharing membership costs")
        else:
            st.success("Your fitness budget looks reasonable!")
    
    with tab2:
        st.subheader("Fitness Finance Tips")
        
        tips = [
            "Buy supplements in bulk to save money in the long run",
            "Consider home workouts to save on gym membership costs",
            "Look for second-hand equipment instead of buying new",
            "Plan your meals to avoid expensive last-minute food choices",
            "Consider training certifications to potentially earn while you learn",
            "Track your fitness spending to identify areas for savings"
        ]
        
        for i, tip in enumerate(tips):
            st.markdown(f"""
            <div class="chat-bubble fade-in">
                <h4>💡 Tip #{i+1}:</h4>
                <p>{tip}</p>
            </div>
            """, unsafe_allow_html=True)
    st.markdown('</div>', unsafe_allow_html=True)

# --- Sports Person Dashboard ---
def sports_dashboard():
    st.markdown(f"<h2 style='text-align: center;'>⚽ {st.session_state.user_role} Dashboard</h2>", unsafe_allow_html=True)
    st.markdown('<div class="sports-bg">', unsafe_allow_html=True)
    
    st.info("Financial management for athletes - equipment, training, and competition expenses")
    
    tab1, tab2 = st.tabs(["💰 Expense Tracker", "🏆 Income Opportunities"])
    
    with tab1:
        st.subheader("Sports Expense Tracker")
        
        col1, col2 = st.columns(2)
        
        with col1:
            equipment = st.number_input("Monthly Equipment Costs ($)", min_value=0, value=75, step=5)
            training = st.number_input("Monthly Training Fees ($)", min_value=0, value=100, step=10)
            
        with col2:
            competition = st.number_input("Monthly Competition Costs ($)", min_value=0, value=150, step=10)
            travel = st.number_input("Monthly Travel Expenses ($)", min_value=0, value=50, step=5)
            
        total_sports = equipment + training + competition + travel
        
        st.metric("Total Monthly Sports Expenses", f"${total_sports}")
        
        # Sports expense analysis
        categories = ["Equipment", "Training", "Competition", "Travel"]
        values = [equipment, training, competition, travel]
        
        fig, ax = plt.subplots()
        ax.pie(values, labels=categories, autopct='%1.1f%%', startangle=90)
        ax.axis('equal')
        ax.set_title('Sports Expenses Breakdown')
        st.pyplot(fig)
        
        if total_sports > 300:
            st.warning("Consider seeking sponsorships or partnerships to offset costs")
        else:
            st.success("Your sports budget looks manageable!")
    
    with tab2:
        st.subheader("Sponsorship & Income Opportunities")
        
        st.markdown("""
        <div class="chat-bubble">
            <h4>🏆 Local Sponsorships</h4>
            <p>Approach local businesses for sponsorship deals. Even small amounts help offset costs.</p>
        </div>
        """, unsafe_allow_html=True)
        
        st.markdown("""
        <div class="chat-bubble">
            <h4>🎯 Coaching Opportunities</h4>
            <p>Offer coaching sessions to beginners to generate additional income.</p>
        </div>
        """, unsafe_allow_html=True)
        
        st.markdown("""
        <div class="chat-bubble">
            <h4>📱 Social Media Monetization</h4>
            <p>Build a following and explore brand partnerships related to your sport.</p>
        </div>
        """, unsafe_allow_html=True)
        
        st.markdown("""
        <div class="chat-bubble">
            <h4>🏅 Competition Winnings</h4>
            <p>Research competitions with prize money and focus on those that align with your skills.</p>
        </div>
        """, unsafe_allow_html=True)
        
        st.markdown("""
        <div class="chat-bubble">
            <h4>👕 Merchandise Sales</h4>
            <p>Consider creating and selling branded merchandise to your fan base.</p>
        </div>
        """, unsafe_allow_html=True)
        
        # Income potential chart
        income_sources = ['Coaching', 'Sponsorships', 'Competitions', 'Merchandise']
        potential_income = [200, 300, 150, 100]  # Example values
        
        fig, ax = plt.subplots()
        ax.bar(income_sources, potential_income)
        ax.set_ylabel('Potential Monthly Income ($)')
        ax.set_title('Income Opportunities for Athletes')
        st.pyplot(fig)
    st.markdown('</div>', unsafe_allow_html=True)

# --- Main App Logic ---
def main():
    if st.session_state.page == 'home':
        home_page()
    elif st.session_state.page == 'dashboard':
        if st.button("← Back to Home"):
            st.session_state.page = 'home'
            st.session_state.user_role = None
            st.session_state.expenses = []
            st.rerun()
            
        if st.session_state.user_role == 'Student':
            student_dashboard()
        elif st.session_state.user_role == 'Employee':
            employee_dashboard()
        elif st.session_state.user_role == 'Body Building':
            bodybuilding_dashboard()
        elif st.session_state.user_role == 'Sports Person':
            sports_dashboard()
    elif st.session_state.page == 'advisor':
        if st.button("← Back to Home"):
            st.session_state.page = 'home'
            st.session_state.user_role = None
            st.session_state.chat_messages = []
            st.rerun()
        advisor_chat()

if __name__ == "__main__":
    main()